<?php 
$connect = mysqli_connect("localhost", "root", "", "cakeydb");

if(!$connect) {
    die ("connection error");
}
?>