<?php
require ("DB.php");
require_once ("ordertbl.php");
require_once ("custombentocake.php");
require_once ("customcake.php");
require_once ("customcupcake.php");
require_once ("customnumbercake.php");
?>